 # HarvardX CS50W: Web Programming with Python and JavaScript
# Requirements
 Your web application must utilize at least two of Python, JavaScript, and SQL.
 Your web application must be mobile-responsive.
  In README.md, include a short writeup describing your project, what’s contained    in each file you created or modified, and (optionally) any other additional information the staff should know about your project.
 If you’ve added any Python packages that need to be installed in order to run your web application, be sure to add them to requirements.txt!

# Overview

In this project Users will be able to take differents type of quizes, get the results after taking these quizes and get feedback as well on what they did correctly and incorrecty. 
Justification
I consider that this project meets all the expectations raised in the assignment of the CS50W final project, as it is a web platform that implements most of the concepts and techniques taught in the course.

The whole application is based on the Django framework, which allowed  database models, http requests, static files and the page rendering.

 The web application is mobile responsive. I have included bootstrap library to make my front end mobile responsive.

The difference between this web application and previous projects is that this application makes use and manages the data to check the quizes, create the quizes check the results of the assignments instantly. 
My project meet all the requirements below:

 Your web application must be sufficiently distinct from the other projects in this course (and, in addition, may not be based on the old CS50W Pizza project), and more complex than those.
 Your web application must utilize Django (including at least one model) on the back-end and JavaScript on the front-end.
 Your web application must be mobile-responsive.


## Installation
- Install project dependencies by running pip install -r requirements.txt.
- Make and apply migrations by running python manage.py makemigrations and python manage.py migrate.
- Create superuser with python manage.py createsuperuser. This step is optional.


## Files and directories
- `questions` - application directory that handles the questions of the quiz
  - `models.py`: contains 2 models: 
    - the model Questions represents the question to be answered 
    - the model Answer represents the answers suggestions to be picked
- `quiz_proj` - project directory.
- `quizes`:  - application directory that enable to create quizes
   - `static/quizes` contains static contents:
       - main.js: script that run in the `main.html` 
       - quiz.js: script that run in the `quiz.html`
   - `templates/quizes`: conatains the applications templates:
       - main.html: template the show the quizes' characterisques(name, difficulty, minutes, time, score to pass)
       - quiz.html: template that shows teh quiz form  
  - `models.py`: contains 1 models that handles the creation of a quiz with the name, number of question,time and difficulty of the quiz.
  - `views.py`: contains 3 views: 
     - the QuizListView  display a particular quiz,
     - the quiz_data_view which display questions and answers related to the quiz,
     - the save_quiz_view which enables the submittion of the user' answers and his score
- `results`: application directory that enable to get the quiz results of the user
   - `models.py`: contains the Result model which register each user with his quiz score 
- `static`: which contains `styles.css`               
- `templates`: contains the base.html
   - `base.html`: base template. All other tempalates extend it.
                      


       
s
